﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
	public partial class Form1 : Form
	{
		string fileName = "NoName";

		public Form1()
		{
			InitializeComponent();
		}

		private void cutToolStripMenuItem1_Click(object sender, EventArgs e)
		{

		}
		private void SaveSetting()
		{
			Properties.Settings.Default.Lacation = this.Location;
			Properties.Settings.Default.Height = this.Height;
			Properties.Settings.Default.Width = this.Width;
			Properties.Settings.Default.Font = this.Font;
			Properties.Settings.Default.WordWrap = txtVanBan.WordWrap;
			Properties.Settings.Default.Save();
		}
		private void LoadSetting()
		{
			this.Location = Properties.Settings.Default.Lacation;
			this.Height = Properties.Settings.Default.Height;
			this.Width = Properties.Settings.Default.Width;
			this.Font = Properties.Settings.Default.Font;
			txtVanBan.WordWrap = Properties.Settings.Default.WordWrap;
			wordWrapToolStripMenuItem.Checked = txtVanBan.WordWrap;
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			LoadSetting();

			this.Text = "MyNotepad - " + fileName;
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			SaveSetting();
		}

		private void exitToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		private void fontToolStripMenuItem_Click(object sender, EventArgs e)
		{
			fontDialog1.Font = txtVanBan.Font;
			if(fontDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				txtVanBan.Font = fontDialog1.Font;
			}
		}

		private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if(saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK) 
			{
				fileName = saveFileDialog1.FileName;
				System.IO.File.WriteAllText(fileName, txtVanBan.Text);
				this.Text = "MyNotepad - " + fileName;
			}
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if(fileName == "NoName")
			{
				saveAsToolStripMenuItem_Click(null, null);
			}
			else
			{
				System.IO.File.WriteAllText (fileName, txtVanBan.Text);
				this.Text = "MyNotepad - " + fileName;
			}
		}

		private void txtVanBan_TextChanged(object sender, EventArgs e)
		{
			if(txtVanBan.Modified) 
			{
				this.Text = "MyNotepad - " + fileName  + " *";
			}
		}

		private void openToolStripMenuItem_Click(object sender, EventArgs e)
		{ 
			if (txtVanBan.Modified)
			{
				if (MessageBox.Show("Bạn có muốn lưu tệp tin hay không", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.OK)
				{
					saveToolStripMenuItem_Click(null, null);
				}
			}
			if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				fileName = openFileDialog1.FileName;
				txtVanBan.Text = System.IO.File.ReadAllText(fileName);
				this.Text = "MyNotepad - " + fileName;
			}
		}

		private void newToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if (txtVanBan.Modified)
			{
				if (MessageBox.Show("Bạn có muốn lưu tệp tin hay không", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
				{
					saveToolStripMenuItem_Click(null, null);
				}
			}
			fileName = "NoName";
			txtVanBan.Text = " "; 
			this.Text = "MyNotepad - " + fileName;
		}

		private void wordWrapToolStripMenuItem_Click(object sender, EventArgs e)
		{
			if(wordWrapToolStripMenuItem.Checked) 
			{
				txtVanBan.WordWrap = true;
			}
			else
			{
				txtVanBan.WordWrap= false;
			}

		}
	}
}
